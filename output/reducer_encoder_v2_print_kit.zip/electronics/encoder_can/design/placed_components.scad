// Generated from design/placements.json by scripts/update_scad_components.py.
// Mechanical envelopes, not manufacturing models.
module placed_component(r,a,rotation,front,size,pcb_h,c) {
  rotate([0,0,a]) translate([r,0,0]) rotate([0,0,rotation-a])
    color(c) translate([0,0,front ? -size[2]/2 : pcb_h+size[2]/2]) cube(size,center=true);
}
module placed_pad(r,a,rotation,local_xy,size,pcb_h) {
  rotate([0,0,a]) translate([r,0,pcb_h+size[2]/2]) rotate([0,0,rotation-a])
    color("Goldenrod") translate([local_xy[0],-local_xy[1],0]) cube(size,center=true);
}
module encoder_can_placed_components(pcb_h=.8) {
  placed_component(29.29999857,-5.00007236,-90.0,false,[5.1, 5.1, 0.6],pcb_h,"DimGray"); // U1
  placed_component(30.00003342,23.99997306,0.0,false,[3, 3, 1.45],pcb_h,"DimGray"); // U4
  placed_component(28.60017482,57.42125341,90.0,false,[3, 3, 1.45],pcb_h,"DimGray"); // U5
  placed_component(31.41854548,62.82327335,0.0,false,[3, 3, 1.1],pcb_h,"DimGray"); // D1
  placed_component(29.49660997,6.61905332,45.0,false,[2.5, 2, 0.7],pcb_h,"Silver"); // Y1
  placed_component(22.7178344,20.34941528,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R1
  placed_component(25.64702712,17.94042293,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R2
  placed_component(28.93872838,17.49575788,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R3
  placed_component(31.8127333,15.87117861,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R4
  placed_component(24.85819784,-3.92139889,180.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R5
  placed_component(27.80287755,0.82434282,0.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R6
  placed_component(26.73667893,12.52880771,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R7
  placed_component(32.55614381,12.77696379,-90.0,true,[1, 0.5, 0.4],pcb_h,"DimGray"); // R8
  placed_component(30.62972319,20.44657757,0.0,true,[1.6, 0.8, 0.55],pcb_h,"DimGray"); // R9
  placed_component(27.1207227,2.23994767,180.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C1
  placed_component(32.30061821,-11.06641852,0.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C2
  placed_component(24.68299009,-6.98105741,0.0,true,[1.6, 0.8, 0.95],pcb_h,"BurlyWood"); // C3
  placed_component(31.89043744,-4.31602752,90.0,true,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C4
  placed_component(29.59746611,-4.65110804,90.0,true,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C5
  placed_component(26.03766503,3.08218082,0.0,true,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C6
  placed_component(32.15960199,5.71059314,-90.0,true,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C7
  placed_component(27.41550656,27.12584025,180.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C8
  placed_component(27.98303057,29.31313936,180.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C9
  placed_component(29.39459984,52.11646857,90.0,false,[1.6, 0.8, 0.95],pcb_h,"BurlyWood"); // C10
  placed_component(31.94526569,54.17042484,0.0,false,[1.6, 0.8, 0.95],pcb_h,"BurlyWood"); // C11
  placed_component(23.91024885,1.67763947,90.0,true,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C12
  placed_component(26.87905504,4.39543561,180.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C13
  placed_component(31.85671044,3.41926782,0.0,false,[1, 0.5, 0.55],pcb_h,"BurlyWood"); // C14
  placed_pad(30.09998402,67.99990243,90.0,[-2.25,0],[1,2,.08],pcb_h); // J1
  placed_pad(30.09998402,67.99990243,90.0,[-0.75,0],[1,2,.08],pcb_h); // J1
  placed_pad(30.09998402,67.99990243,90.0,[0.75,0],[1,2,.08],pcb_h); // J1
  placed_pad(30.09998402,67.99990243,90.0,[2.25,0],[1,2,.08],pcb_h); // J1
  placed_pad(30.00003827,-44.00005921,-44.0,[0,-2.54],[1,1,.08],pcb_h); // J2
  placed_pad(30.00003827,-44.00005921,-44.0,[0,-1.27],[1,1,.08],pcb_h); // J2
  placed_pad(30.00003827,-44.00005921,-44.0,[0,0],[1,1,.08],pcb_h); // J2
  placed_pad(30.00003827,-44.00005921,-44.0,[0,1.27],[1,1,.08],pcb_h); // J2
  placed_pad(30.00003827,-44.00005921,-44.0,[0,2.54],[1,1,.08],pcb_h); // J2
  placed_pad(30.00000148,-33.00006409,-33.0,[0,0],[1,1,.08],pcb_h); // TP1
}

module encoder_can_placed_crystal(pcb_h=.8) {
  placed_component(29.49660997,6.61905332,45.0,false,[2.5, 2, 0.7],pcb_h,"Silver");
}

function encoder_can_mcu_height() = .6;
module encoder_can_mcu_clearance(pcb_bottom_z=11,xy_gap=.2,z_gap=.15,eps=.01) {
  rotate([0,0,-5.00007236]) translate([29.29999857,0,pcb_bottom_z-encoder_can_mcu_height()-z_gap])
    rotate([0,0,-84.99992764]) translate([-5.1/2-xy_gap,-5.1/2-xy_gap,0])
      cube([5.1+2*xy_gap,5.1+2*xy_gap,encoder_can_mcu_height()+z_gap+eps]);
}

module encoder_can_rear_clearances(pcb_bottom_z=11,xy_gap=.2,z_gap=.15,eps=.01) {
  // U1: actual maximum package height, plus assembly clearance.
  rotate([0,0,-5.00007236]) translate([29.29999857,0,pcb_bottom_z-0.6-z_gap])
    rotate([0,0,-84.99992764]) translate([-5.1/2-xy_gap,-5.1/2-xy_gap,0])
      cube([5.1+2*xy_gap,5.1+2*xy_gap,0.6+z_gap+eps]);
  // U4: actual maximum package height, plus assembly clearance.
  rotate([0,0,23.99997306]) translate([30.00003342,0,pcb_bottom_z-1.45-z_gap])
    rotate([0,0,-23.99997306]) translate([-3/2-xy_gap,-3/2-xy_gap,0])
      cube([3+2*xy_gap,3+2*xy_gap,1.45+z_gap+eps]);
  // U5: actual maximum package height, plus assembly clearance.
  rotate([0,0,57.42125341]) translate([28.60017482,0,pcb_bottom_z-1.45-z_gap])
    rotate([0,0,32.57874659]) translate([-3/2-xy_gap,-3/2-xy_gap,0])
      cube([3+2*xy_gap,3+2*xy_gap,1.45+z_gap+eps]);
  // D1: actual maximum package height, plus assembly clearance.
  rotate([0,0,62.82327335]) translate([31.41854548,0,pcb_bottom_z-1.1-z_gap])
    rotate([0,0,-62.82327335]) translate([-3/2-xy_gap,-3/2-xy_gap,0])
      cube([3+2*xy_gap,3+2*xy_gap,1.1+z_gap+eps]);
  // Y1: actual maximum package height, plus assembly clearance.
  rotate([0,0,6.61905332]) translate([29.49660997,0,pcb_bottom_z-0.7-z_gap])
    rotate([0,0,38.38094668]) translate([-2.5/2-xy_gap,-2/2-xy_gap,0])
      cube([2.5+2*xy_gap,2+2*xy_gap,0.7+z_gap+eps]);
  // C1: actual maximum package height, plus assembly clearance.
  rotate([0,0,2.23994767]) translate([27.1207227,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,177.76005233]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
  // C2: actual maximum package height, plus assembly clearance.
  rotate([0,0,-11.06641852]) translate([32.30061821,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,11.06641852]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
  // C8: actual maximum package height, plus assembly clearance.
  rotate([0,0,27.12584025]) translate([27.41550656,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,152.87415975]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
  // C9: actual maximum package height, plus assembly clearance.
  rotate([0,0,29.31313936]) translate([27.98303057,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,150.68686064]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
  // C10: actual maximum package height, plus assembly clearance.
  rotate([0,0,52.11646857]) translate([29.39459984,0,pcb_bottom_z-0.95-z_gap])
    rotate([0,0,37.88353143]) translate([-1.6/2-xy_gap,-0.8/2-xy_gap,0])
      cube([1.6+2*xy_gap,0.8+2*xy_gap,0.95+z_gap+eps]);
  // C11: actual maximum package height, plus assembly clearance.
  rotate([0,0,54.17042484]) translate([31.94526569,0,pcb_bottom_z-0.95-z_gap])
    rotate([0,0,-54.17042484]) translate([-1.6/2-xy_gap,-0.8/2-xy_gap,0])
      cube([1.6+2*xy_gap,0.8+2*xy_gap,0.95+z_gap+eps]);
  // C13: actual maximum package height, plus assembly clearance.
  rotate([0,0,4.39543561]) translate([26.87905504,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,175.60456439]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
  // C14: actual maximum package height, plus assembly clearance.
  rotate([0,0,3.41926782]) translate([31.85671044,0,pcb_bottom_z-0.55-z_gap])
    rotate([0,0,-3.41926782]) translate([-1/2-xy_gap,-0.5/2-xy_gap,0])
      cube([1+2*xy_gap,0.5+2*xy_gap,0.55+z_gap+eps]);
}
